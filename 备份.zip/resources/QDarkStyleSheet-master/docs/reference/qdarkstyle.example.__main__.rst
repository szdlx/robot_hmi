qdarkstyle.example.\_\_main\_\_ module
======================================

.. automodule:: qdarkstyle.example.__main__
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
