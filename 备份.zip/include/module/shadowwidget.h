#ifndef SHADOWWIDGET_H
#define SHADOWWIDGET_H

#include <QWidget>

class ShadowWidget:public QWidget
{
public:
    ShadowWidget(QWidget* parent=nullptr);
};

#endif // SHADOWWIDGET_H
